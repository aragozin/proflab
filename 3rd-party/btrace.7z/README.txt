BTrace script is modified to enable unsafe scripts

Please insert absolute paths to Java and BTrace directory into placeholder in btrace.bat
